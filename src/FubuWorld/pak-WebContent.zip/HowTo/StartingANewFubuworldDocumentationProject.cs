
using FubuDocs;

namespace FubuWorld.HowTo
{
    public class StartingANewFubuworldDocumentationProject : Topic
    {
        public StartingANewFubuworldDocumentationProject() : base("Starting a new FubuWorld Documentation Project")
        {
        }
    }
}