
using FubuDocs;

namespace FubuWorld.HowTo.FubuDocsRunner
{
    public class GeneratingTheEntireTopicTree : Topic
    {
        public GeneratingTheEntireTopicTree() : base("Generating the Entire Topic Tree")
        {
        }
    }
}