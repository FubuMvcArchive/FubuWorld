
using FubuDocs;

namespace FubuWorld.HowTo.FubuDocsRunner
{
    public class BottlingTheFubuworldProject : Topic
    {
        public BottlingTheFubuworldProject() : base("Bottling the FubuWorld ProjectRoot")
        {
        }
    }
}