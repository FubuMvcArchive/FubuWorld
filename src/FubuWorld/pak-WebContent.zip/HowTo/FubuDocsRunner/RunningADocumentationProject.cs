
using FubuDocs;

namespace FubuWorld.HowTo.FubuDocsRunner
{
    public class RunningADocumentationProject : Topic
    {
        public RunningADocumentationProject() : base("Running a Documentation Project")
        {
        }
    }
}