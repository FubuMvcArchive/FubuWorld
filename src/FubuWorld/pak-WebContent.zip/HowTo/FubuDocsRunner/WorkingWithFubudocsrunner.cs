
using FubuDocs;

namespace FubuWorld.HowTo.FubuDocsRunner
{
    public class WorkingWithFubudocsrunner : Topic
    {
        public WorkingWithFubudocsrunner() : base("Working with FubuDocsRunner")
        {
        }
    }
}