
using FubuDocs;

namespace FubuWorld.HowTo.FubuDocsRunner
{
    public class AddASingleTopic : Topic
    {
        public AddASingleTopic() : base("Add a Single Topic")
        {
        }
    }
}