
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class CommandLineResults : Topic
    {
        public CommandLineResults() : base("Command Line Results")
        {
        }
    }
}