
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class TopicRelatedHelpers : Topic
    {
        public TopicRelatedHelpers() : base("Topic Related Helpers")
        {
        }
    }
}