
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class CodeSnippets : Topic
    {
        public CodeSnippets() : base("Code Snippets")
        {
        }
    }
}