
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class DocumentationViewHelpers : Topic
    {
        public DocumentationViewHelpers() : base("Documentation View Helpers")
        {
        }
    }
}