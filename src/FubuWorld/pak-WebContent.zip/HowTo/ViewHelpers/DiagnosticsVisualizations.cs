
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class DiagnosticsVisualizations : Topic
    {
        public DiagnosticsVisualizations() : base("Diagnostics Visualizations")
        {
        }
    }
}