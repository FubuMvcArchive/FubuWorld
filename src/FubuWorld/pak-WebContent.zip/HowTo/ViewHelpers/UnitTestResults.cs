
using FubuDocs;

namespace FubuWorld.HowTo.ViewHelpers
{
    public class UnitTestResults : Topic
    {
        public UnitTestResults() : base("Unit Test Results")
        {
        }
    }
}