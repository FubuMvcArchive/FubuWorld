
using FubuDocs;

namespace FubuWorld.HowTo.Topics
{
    public class AddingANewTopic : Topic
    {
        public AddingANewTopic() : base("Adding a New Topic")
        {
        }
    }
}