
using FubuDocs;

namespace FubuWorld.HowTo.Topics
{
    public class TheTopicNavigationStructure : Topic
    {
        public TheTopicNavigationStructure() : base("The 'Topic' Navigation Structure")
        {
        }
    }
}