
using FubuDocs;

namespace FubuWorld.HowTo.Topics
{
    public class SparkLayoutForATopic : Topic
    {
        public SparkLayoutForATopic() : base("Spark Layout for a Topic")
        {
        }
    }
}