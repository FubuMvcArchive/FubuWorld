
using FubuDocs;

namespace FubuWorld.HowTo.Topics
{
    public class TopicNavigation : Topic
    {
        public TopicNavigation() : base("Topic Navigation")
        {
        }
    }
}