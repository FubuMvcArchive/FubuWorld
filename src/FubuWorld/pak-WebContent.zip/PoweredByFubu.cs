﻿using FubuMVC.Diagnostics.Runtime;

namespace FubuWorld
{
    public class PoweredByFubu
    {
        public RequestLog CurrentRequest { get; set; }
    }
}