﻿using System.Linq;
using System.Collections.Generic;

namespace FubuWorld.Topics
{
    public static class StringExtensions
    {
         public static string AppendUrl(this string url, string part)
         {
             return (url + "/" + part).Replace("//", "/");
         }

        public static string ParentUrl(this string url)
        {
            return url.Contains("/") ? url.Split('/').Reverse().Skip(1).Reverse().Join("/") : null;
        }
    }
}